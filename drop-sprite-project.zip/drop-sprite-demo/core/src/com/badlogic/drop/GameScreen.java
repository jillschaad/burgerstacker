// Jill Schaad Project 1

package com.badlogic.drop;


import java.util.Iterator;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite; // Sprite demo
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.TimeUtils;

public class GameScreen implements Screen {
  	final Drop game;

	Texture dropImage;
	Sprite dropSprite; // Sprite demo

	Texture bucketImage;
	Sound dropSound;
	Music rainMusic;
	OrthographicCamera camera;
	Rectangle bucket;
	Array<Rectangle> buckets;
	Array<Rectangle> raindrops;
	long lastDropTime;
	int dropsGathered;
	long colorFlash;
	// Project 1: make new sprite for bucketsprite
	Sprite bucketSprite;
	float diagonal;
	
	// Sprite demo
	int framecount = 1;
	int incr = 1;

	public GameScreen(final Drop gam) {
		this.game = gam;

		// load the images for the droplet and the bucket, 64x64 pixels each
		dropImage = new Texture(Gdx.files.internal("droplet.png"));
		bucketImage = new Texture(Gdx.files.internal("bucket.png"));

	    // Sprite demo
		// construct sprite from dropImage texture
		// Project 1: make bucket a sprite
	    dropSprite = new Sprite(dropImage);
	    bucketSprite = new Sprite(bucketImage);

		// load the drop sound effect and the rain background "music"
		dropSound = Gdx.audio.newSound(Gdx.files.internal("drop.wav"));
		rainMusic = Gdx.audio.newMusic(Gdx.files.internal("rain.mp3"));
		rainMusic.setLooping(true);

		// create the camera and the SpriteBatch
		camera = new OrthographicCamera();
		camera.setToOrtho(false, 800, 480);

		// create a Rectangle to logically represent the bucket
		bucket = new Rectangle();
		bucket.x = 800 / 2 - 64 / 2; // center the bucket horizontally
		bucket.y = 20; // bottom left corner of the bucket is 20 pixels above
						// the bottom screen edge
		bucket.width = 64;
		bucket.height = 64;

		// create the raindrops array and spawn the first raindrop
		raindrops = new Array<Rectangle>();
		spawnRaindrop();

	}

	private void spawnRaindrop() {
		Rectangle raindrop = new Rectangle();
		raindrop.x = MathUtils.random(0, 800 - 64);
		raindrop.y = 480;
		// Project 1: change sprite size so the bucket has to be more precise to catch them.
		raindrop.width = 25;
		raindrop.height = 25;
		raindrops.add(raindrop);
		lastDropTime = TimeUtils.nanoTime();
	}

	@Override
	public void render(float delta) {
		// clear the screen with a dark blue color. The
		// arguments to glClearColor are the red, green
		// blue and alpha component in the range [0,1]
		// of the color to be used to clear the screen.
		Gdx.gl.glClearColor(0, 0, 0.2f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		// tell the camera to update its matrices.
		camera.update();

		// tell the SpriteBatch to render in the
		// coordinate system specified by the camera.
		game.batch.setProjectionMatrix(camera.combined);


		// begin a new batch and draw the bucket and
		// all drops
		// Project 1: change "drops collected" to right side and add smaller raindrop.
		game.batch.begin();
		game.font.draw(game.batch, "Drops Collected: " + dropsGathered, 670, 480);
		game.batch.draw(dropImage, 650, 465, 15, 15);
		game.batch.draw(bucketSprite, bucket.x, bucket.y);

		// Project 1: set position of sprite so it's over the bucket image
		bucketSprite.setPosition(bucket.x, bucket.y);
		bucketSprite.draw(game.batch);

		for (Rectangle raindrop : raindrops) {
			// Sprite demo:
			// Old - draws texture at rectangles
			// game.batch.draw(dropImage, raindrop.x, raindrop.y);
	        // 
			// New - draws sprite at rectangles
			// Not ideal to have to setPosition in here, but there's only one dropSprite,
	        // and we have to change its position to a raindrop Rectangle's x,y before each draw.
	        dropSprite.setPosition(raindrop.x, raindrop.y);
	        dropSprite.draw(game.batch);

		}

		game.batch.end();

		// process user input
		if (Gdx.input.isTouched()) {
			Vector3 touchPos = new Vector3();
			touchPos.set(Gdx.input.getX(), Gdx.input.getY(), 0);
			camera.unproject(touchPos);
			bucket.x = touchPos.x - 64 / 2;
		}
		if (Gdx.input.isKeyPressed(Keys.LEFT))
			bucket.x -= 200 * Gdx.graphics.getDeltaTime();
		if (Gdx.input.isKeyPressed(Keys.RIGHT))
			bucket.x += 200 * Gdx.graphics.getDeltaTime();

		// make sure the bucket stays within the screen bounds
		if (bucket.x < 0)
			bucket.x = 0;
		if (bucket.x > 800 - 64)
			bucket.x = 800 - 64;

		// check if we need to create a new raindrop
		// Project 1: changes the time new raindrops are spawned to make them spawn faster.
		if (TimeUtils.nanoTime() - lastDropTime > 333333333)
			spawnRaindrop();

		// move the raindrops, remove any that are beneath the bottom edge of
		// the screen or that hit the bucket. In the later case we play back
		// a sound effect as well.
		Iterator<Rectangle> iter = raindrops.iterator();
		while (iter.hasNext()) {
			Rectangle raindrop = iter.next();
			raindrop.y -= 200 * Gdx.graphics.getDeltaTime();

			// Project 1: raindrops will fall diagonally
			diagonal = MathUtils.random(-10, 10);

			if (raindrop.y < 480 && raindrop.y > 280) {
				// project 1: make raindrops accelerate
				raindrop.y -= 100 * Gdx.graphics.getDeltaTime();
				raindrop.x -= diagonal;
			} else {
				// project 1: make raindrops accelerate halfway down
				raindrop.y -= 800 * Gdx.graphics.getDeltaTime();
				raindrop.x -= diagonal;
			}

			if (raindrop.y + 64 < 0)
				iter.remove();
			// Project 1: add this if statement so if raindrops go diagonal
			// they will be removed if they go off either side.
			if (raindrop.x + 64 < 0)
				iter.remove();
			if (raindrop.x + 64 > 800)
				iter.remove();

			if (raindrop.overlaps(bucket)) {

				dropsGathered++;
				// Project 1: changes bucket color
				bucketSprite.setColor(44444);
				colorFlash = TimeUtils.nanoTime();


				dropSound.play();
				iter.remove();

			}

		}

		// Project 1: have color flash and reset
		if (TimeUtils.nanoTime() - colorFlash > 200000000) bucketSprite.setColor(255255255);

		// Sprite demo:
	    // Apply effects to the Sprite:
		// (See the Sprite class at http://bit.ly/2dAJYbi)
		if (framecount > 99 || framecount < 1) incr *= -1;
		framecount = framecount + incr;


		// Project 1: take out rain drop scaling: dropSprite.scale(incr/100.0f); // relative method
		// dropSprite.setScale(1 + framecount/100.0f); // absolute method
	    
	} //end render()

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void show() {
		// start the playback of the background music
		// when the screen is shown
		rainMusic.play();
	}

	@Override
	public void hide() {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void dispose() {
		dropImage.dispose();
		bucketImage.dispose();
		dropSound.dispose();
		rainMusic.dispose();
	}

}